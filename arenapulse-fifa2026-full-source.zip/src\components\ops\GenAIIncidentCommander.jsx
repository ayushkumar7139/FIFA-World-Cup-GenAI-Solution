import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Sparkles, 
  Megaphone, 
  Radio, 
  Users, 
  Activity, 
  CheckCircle, 
  Volume2, 
  VolumeX, 
  Clock, 
  Play, 
  PlusCircle, 
  FileText 
} from 'lucide-react';
import { generateTacticalSOP } from '../../services/geminiService';

export default function GenAIIncidentCommander({ stadium }) {
  const [activeIncidents, setActiveIncidents] = useState([
    {
      id: 'inc-1',
      title: 'Perimeter Bottleneck & Turnstile Scanner Latency',
      location: 'Gate C (North Concourse)',
      severity: 'High',
      time: '2 mins ago',
      status: 'Active',
      description: 'Density spike exceeding 3.2 persons/m²; two RFID turnstiles experiencing intermittent network timeout.'
    },
    {
      id: 'inc-2',
      title: 'Medical Assistance Requested',
      location: 'Section 114, Row 12',
      severity: 'Medium',
      time: '6 mins ago',
      status: 'Dispatched',
      description: 'Patron requesting heat exhaustion evaluation. First Aid Station 3 notified.'
    },
    {
      id: 'inc-3',
      title: 'Unattended Bag Flagged by Security K9 Unit',
      location: 'Lower Concourse West (Near Gate A)',
      severity: 'Critical',
      time: '11 mins ago',
      status: 'SOP Generated',
      description: 'Backpack observed near merchandise kiosk. Perimeter established.'
    }
  ]);

  const [selectedIncident, setSelectedIncident] = useState(activeIncidents[0]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [sopResult, setSopResult] = useState(null);
  const [isPlayingPA, setIsPlayingPA] = useState(false);
  const [activePaLang, setActivePaLang] = useState('en');

  const handleGenerateSOP = async (incident = selectedIncident) => {
    setIsGenerating(true);
    setSopResult(null);

    try {
      const sop = await generateTacticalSOP({
        incidentType: incident.title,
        stadium,
        severity: incident.severity,
        location: incident.location
      });
      setSopResult(sop);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const playPaBroadcast = (script) => {
    if (!('speechSynthesis' in window)) return;
    if (isPlayingPA) {
      window.speechSynthesis.cancel();
      setIsPlayingPA(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(script);
    utterance.lang = activePaLang === 'es' ? 'es-MX' : activePaLang === 'fr' ? 'fr-FR' : 'en-US';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsPlayingPA(false);
    utterance.onerror = () => setIsPlayingPA(false);

    window.speechSynthesis.speak(utterance);
    setIsPlayingPA(true);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <h2 className="text-lg font-bold text-white font-display">
              GenAI Incident Commander & Tactical SOP Engine
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Automated threat assessment, tactical workflow synthesis, and trilingual public address broadcasting
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-rose-950/40 border border-rose-800/40 px-3 py-1.5 rounded-xl text-xs text-rose-300 font-bold">
          <Radio className="w-4 h-4 text-rose-400 animate-pulse" />
          <span>Active Command Link: {stadium.name.split('(')[0]}</span>
        </div>
      </div>

      {/* Main Grid: Incident Log + SOP Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Incident List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Live Security & Ops Incidents</h3>
            <span className="text-[10px] text-slate-400 font-semibold">{activeIncidents.length} Logged</span>
          </div>

          <div className="space-y-2.5">
            {activeIncidents.map((inc) => {
              const isSelected = selectedIncident.id === inc.id;
              const isCrit = inc.severity === 'Critical';
              const isHigh = inc.severity === 'High';

              return (
                <div
                  key={inc.id}
                  onClick={() => {
                    setSelectedIncident(inc);
                    setSopResult(null);
                  }}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800 border-emerald-500 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                      isCrit ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                      isHigh ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    }`}>
                      {inc.severity} Severity
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{inc.time}</span>
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-white leading-snug">{inc.title}</h4>
                  <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                    <span>{inc.location}</span>
                    <span className="text-emerald-400 font-medium">{inc.status}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Action Button */}
          <button
            onClick={() => handleGenerateSOP(selectedIncident)}
            disabled={isGenerating}
            className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin text-slate-950" />
                <span>Synthesizing Tactical SOP via Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 fill-current text-slate-950" />
                <span>Generate GenAI Tactical SOP for Incident</span>
              </>
            )}
          </button>
        </div>

        {/* SOP & Broadcast Display */}
        <div className="lg:col-span-2">
          {sopResult ? (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 animate-in fade-in duration-200">
              {/* SOP Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-2">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/30">
                      {sopResult.incidentCode}
                    </span>
                    <h3 className="text-sm font-bold text-white">{selectedIncident.title}</h3>
                  </div>
                  <p className="text-xs text-rose-300 mt-1 font-medium">{sopResult.threatAssessment}</p>
                </div>

                {/* Resource Allocations Pill */}
                <div className="flex items-center space-x-2 text-[11px] bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                  <span className="text-slate-400">Deployed:</span>
                  <span className="text-white font-bold">{sopResult.resourceAllocations.marshals} Marshals</span>
                  <span>•</span>
                  <span className="text-teal-300 font-bold">{sopResult.resourceAllocations.volunteers} Volunteers</span>
                </div>
              </div>

              {/* 5-Step Action Protocol */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <span>Tactical Execution Checklist</span>
                </h4>
                <div className="space-y-1.5">
                  {sopResult.tacticalActions.map((action, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-xs bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="text-slate-200">{action}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Multilingual PA Broadcast Section */}
              <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                    <Megaphone className="w-4 h-4 text-blue-400" />
                    <span>Trilingual Stadium PA Broadcast Script</span>
                  </h4>

                  {/* Language switch */}
                  <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-[11px]">
                    <button
                      onClick={() => setActivePaLang('en')}
                      className={`px-2 py-0.5 rounded font-bold transition-colors ${
                        activePaLang === 'en' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      English
                    </button>
                    <button
                      onClick={() => setActivePaLang('es')}
                      className={`px-2 py-0.5 rounded font-bold transition-colors ${
                        activePaLang === 'es' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Español
                    </button>
                    <button
                      onClick={() => setActivePaLang('fr')}
                      className={`px-2 py-0.5 rounded font-bold transition-colors ${
                        activePaLang === 'fr' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Français
                    </button>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-900/90 rounded-xl border border-blue-500/30 text-xs text-slate-200 leading-relaxed font-sans italic">
                  "{sopResult.paBroadcast[activePaLang]}"
                </div>

                <div className="flex items-center justify-between">
                  <button
                    onClick={() => playPaBroadcast(sopResult.paBroadcast[activePaLang])}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      isPlayingPA
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/20'
                    }`}
                  >
                    {isPlayingPA ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5" />
                        <span>Cease PA Broadcast</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Broadcast Live via Stadium PA</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => alert(`Mobile Geo-Push Notification Sent to 4,200 fans within 300m radius of ${selectedIncident.location}!`)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-colors"
                  >
                    Dispatch Mobile App Push Reroute
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[380px] bg-slate-950/60 border border-dashed border-slate-800 rounded-xl flex flex-col items-center justify-center p-6 text-center text-slate-400">
              <Sparkles className="w-10 h-10 text-slate-600 mb-3" />
              <h4 className="text-sm font-bold text-slate-300">GenAI Tactical Commander Ready</h4>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Select an incident from the left and click <strong>Generate GenAI Tactical SOP</strong> to synthesize marshaling procedures, staff deployment orders, and multilingual announcements.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
