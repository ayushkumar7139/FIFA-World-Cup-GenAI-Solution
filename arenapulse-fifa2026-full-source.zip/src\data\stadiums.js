export const STADIUMS = {
  metlife: {
    id: 'metlife',
    name: 'MetLife Stadium (New York / New Jersey)',
    city: 'East Rutherford, NJ, USA',
    role: 'FIFA World Cup 2026 Final Host',
    capacity: 82500,
    flag: '🇺🇸',
    currency: 'USD',
    transitHub: 'Meadowlands Rail Station & NJ Transit Express Shuttles',
    emergencyNumber: '911 (Stadium Security: Ext 4000)',
    zones: [
      { id: 'z-a', name: 'Gate A - MetLife Plaza (West)', density: 'Moderate', queueMin: 4, accessible: true, status: 'smooth' },
      { id: 'z-b', name: 'Gate B - Verizon West Concourse', density: 'Low', queueMin: 2, accessible: true, status: 'smooth' },
      { id: 'z-c', name: 'Gate C - Bud Light Concourse (North)', density: 'Critical Surge', queueMin: 18, accessible: true, status: 'surging' },
      { id: 'z-d', name: 'Gate D - HCLTech Concourse (East)', density: 'High', queueMin: 11, accessible: true, status: 'moderate' },
      { id: 'z-e', name: 'Gate E - Pepsi Plaza (South)', density: 'Moderate', queueMin: 5, accessible: true, status: 'smooth' },
      { id: 'z-f', name: 'VIP & Media Entrance (Midfield)', density: 'Low', queueMin: 1, accessible: true, status: 'smooth' },
    ],
    concessions: [
      { id: 'c1', name: 'Garden State Halal Cart', section: 'Sec 114', tier: 'Lower Tier', type: 'Halal / Middle Eastern', waitMin: 4, dietary: ['Halal', 'Vegetarian'], signature: 'Lamb & Rice Platter ($16), Falafel Pita ($12)' },
      { id: 'c2', name: 'Jersey Shore Boardwalk Tacos', section: 'Sec 128', tier: 'Lower Tier', type: 'Mexican Street Tacos', waitMin: 12, dietary: ['Gluten-Free Option'], signature: 'Carne Asada Tacos ($15), Loaded Nacho Boat ($14)' },
      { id: 'c3', name: 'Green Kick 100% Plant-Based', section: 'Sec 220', tier: 'Club Tier', type: 'Vegan & Organic', waitMin: 3, dietary: ['Vegan', 'Gluten-Free', 'Organic'], signature: 'World Cup Beyond Brat ($13), Quinoa Fiesta Bowl ($14)' },
      { id: 'c4', name: 'Empire Kosher Grill', section: 'Sec 103', tier: 'Lower Tier', type: 'Glatt Kosher', waitMin: 6, dietary: ['Kosher'], signature: 'Pastrami on Rye ($18), Hebrew National Frank ($9)' },
      { id: 'c5', name: 'Gotham Craft Brew & Pretzel Hub', section: 'Sec 334', tier: 'Upper Tier', type: 'Beverages & Snacks', waitMin: 8, dietary: ['Vegetarian'], signature: 'Zero-Waste Cup Draft Beer ($14), Jumbo Bavarian Pretzel ($8)' },
    ],
    accessibilityHubs: [
      { id: 'acc1', name: 'Quiet Sensory Calm Room', section: 'Sec 118 & Sec 232', desc: 'Sound-dampened sensory space with sensory bags, weighted lap pads, dim lighting & trained specialists.' },
      { id: 'acc2', name: 'Wheelchair / ADA Express Elevators', section: 'Elevator Banks 2, 4, 7', desc: 'Direct priority elevator access to all concourse tiers and ADA viewing platforms.' },
      { id: 'acc3', name: 'FIFA Audio-Descriptive Commentary Desk', section: 'Guest Services Sec 124', desc: 'Complimentary assistive RF receivers for blind & low-vision fans with live bilingual commentary.' },
      { id: 'acc4', name: 'Universal Adult Changing Facility', section: 'First Aid Sec 140', desc: 'Height-adjustable adult changing tables and electric ceiling hoists.' },
    ],
    transitOptions: [
      { type: 'Rail', name: 'NJ Transit Meadowlands Rail', eta: 'Trains every 6 mins to Secaucus & NYC Penn Station', status: 'On-Schedule' },
      { type: 'Bus', name: 'FIFA Fan Shuttle Route 351', eta: 'Express from Port Authority Bus Terminal (22 mins)', status: 'Light Traffic' },
      { type: 'Rideshare', name: 'Uber / Lyft Zone Lot E', eta: 'Surge pricing active; 14 min wait', status: 'Congested' },
      { type: 'Bicycle', name: 'Green Path Bikeshare Valet', eta: 'Free bike valet at Gate B with carbon offset tokens', status: 'Available' },
    ],
    upcomingMatch: {
      fixture: 'FIFA World Cup 2026 - FINAL',
      date: 'Sunday, July 19, 2026',
      time: '19:00 EDT',
      teams: 'Finalist A vs Finalist B',
      projectedAttendance: 82500
    }
  },

  azteca: {
    id: 'azteca',
    name: 'Estadio Azteca (Mexico City)',
    city: 'Mexico City, Mexico',
    role: 'FIFA World Cup 2026 Opening Match Host',
    capacity: 87523,
    flag: '🇲🇽',
    currency: 'MXN',
    transitHub: 'Tren Ligero Estación Estadio Azteca & Calzada de Tlalpan Metro Line 2',
    emergencyNumber: '911 (Protección Civil Azteca: Ext 105)',
    zones: [
      { id: 'z-a', name: 'Acceso Insurgentes (Puerta 1)', density: 'Low', queueMin: 3, accessible: true, status: 'smooth' },
      { id: 'z-b', name: 'Acceso Calzada de Tlalpan (Puerta 2)', density: 'Critical Surge', queueMin: 22, accessible: true, status: 'surging' },
      { id: 'z-c', name: 'Puerta 3 - Explanada Norte', density: 'Moderate', queueMin: 7, accessible: true, status: 'smooth' },
      { id: 'z-d', name: 'Puerta 4 - Rampa Sur Especial', density: 'Low', queueMin: 2, accessible: true, status: 'smooth' },
      { id: 'z-e', name: 'Zona VIP & Palcos Club', density: 'Low', queueMin: 1, accessible: true, status: 'smooth' },
    ],
    concessions: [
      { id: 'c1', name: 'Tacos al Pastor Monumental', section: 'Túnel 8', tier: 'Planta Baja', type: 'Auténtica Comida Mexicana', waitMin: 14, dietary: ['Halal Beef Option', 'Gluten-Free Tortillas'], signature: 'Tacos de Pastor con Piña ($90 MXN)' },
      { id: 'c2', name: 'Taquería Vegetariana & Nopalitos', section: 'Zona 104', tier: 'Planta Baja', type: 'Vegano & Vegetariano', waitMin: 4, dietary: ['Vegan', 'Gluten-Free'], signature: 'Huarache de Nopal y Frijol ($75 MXN)' },
      { id: 'c3', name: 'Cervecería Corona Cero & Bebidas', section: 'Túnel 15', tier: 'Nivel Club', type: 'Bebidas Sin Alcohol & Cervezas', waitMin: 5, dietary: ['Vegetarian'], signature: 'Vaso Conmemorativo Reutilizable ($120 MXN)' },
      { id: 'c4', name: 'Pizzas & Tortas El Diez', section: 'Zona 312', tier: 'Nivel Alto', type: 'Snacks & Tortas', waitMin: 9, dietary: ['Halal Chicken Available'], signature: 'Torta de Milanesa Especial ($110 MXN)' },
    ],
    accessibilityHubs: [
      { id: 'acc1', name: 'Módulo de Inclusión y Sala de Calma', section: 'Acceso Puerta 4', desc: 'Espacio multisensorial adaptado para personas neurodivergentes y con autismo.' },
      { id: 'acc2', name: 'Rampas de Acceso Universal y Elevadores', section: 'Rampa Especial Tlalpan', desc: 'Acceso prioritario 100% libre de escalones para sillas de ruedas.' },
      { id: 'acc3', name: 'Narración Descriptiva en Vivo (Audio)', section: 'Módulo Puerta 1', desc: 'Dispositivos de radiofrecuencia con narración audiodescriptiva en español e inglés.' },
    ],
    transitOptions: [
      { type: 'Train', name: 'Tren Ligero (Estación Estadio Azteca)', eta: 'Conexión directa con Metro Tasqueña (Línea 2)', status: 'Surging' },
      { type: 'Bus', name: 'Metrobús Corredor Especial Tlalpan', eta: 'Unidades cada 4 minutos hacia Centro Histórico', status: 'On-Schedule' },
      { type: 'Shuttle', name: 'FIFA Fan Shuttle Aeropuerto MEX', eta: 'Servicio directo a Terminales 1 y 2 (45 mins)', status: 'Light Traffic' },
    ],
    upcomingMatch: {
      fixture: 'FIFA World Cup 2026 - MATCH 1 (OPENING GAME)',
      date: 'Thursday, June 11, 2026',
      time: '13:00 CST',
      teams: 'Mexico vs Opponent Group A',
      projectedAttendance: 87500
    }
  },

  bcplace: {
    id: 'bcplace',
    name: 'BC Place Stadium (Vancouver)',
    city: 'Vancouver, BC, Canada',
    role: 'FIFA World Cup 2026 Canada Host Venue',
    capacity: 54500,
    flag: '🇨🇦',
    currency: 'CAD',
    transitHub: 'Stadium-Chinatown SkyTrain Station (Expo Line)',
    emergencyNumber: '911 (BC Place Operations: Ext 310)',
    zones: [
      { id: 'z-a', name: 'Gate A - Terry Fox Plaza', density: 'High', queueMin: 12, accessible: true, status: 'moderate' },
      { id: 'z-b', name: 'Gate B - Pacific Boulevard', density: 'Low', queueMin: 3, accessible: true, status: 'smooth' },
      { id: 'z-c', name: 'Gate C - Expo Boulevard (SkyTrain)', density: 'Critical Surge', queueMin: 16, accessible: true, status: 'surging' },
      { id: 'z-d', name: 'Gate D - Robson Street North', density: 'Moderate', queueMin: 6, accessible: true, status: 'smooth' },
      { id: 'z-e', name: 'VIP & Media East Entrance', density: 'Low', queueMin: 1, accessible: true, status: 'smooth' },
    ],
    concessions: [
      { id: 'c1', name: 'Pacific Salmon & Poutine Co.', section: 'Sec 212', tier: 'Main Concourse', type: 'Canadian Specialties', waitMin: 10, dietary: ['Gluten-Free Gravy Available'], signature: 'Wild BC Smoked Salmon Roll ($18 CAD), Classic Poutine ($12 CAD)' },
      { id: 'c2', name: 'Cascadia Pure Vegan Bowls', section: 'Sec 226', tier: 'Main Concourse', type: 'Plant-Based', waitMin: 3, dietary: ['Vegan', 'Gluten-Free', 'Halal-Certified'], signature: 'Crispy Tofu Dragon Bowl ($15 CAD)' },
      { id: 'c3', name: 'Vancouver Dim Sum & Bao Station', section: 'Sec 244', tier: 'Main Concourse', type: 'Asian Fusion', waitMin: 7, dietary: ['Halal Chicken Available', 'Vegetarian'], signature: 'Steamed BBQ Pork Bao ($11 CAD), Har Gow ($13 CAD)' },
      { id: 'c4', name: 'Raincity Zero-Waste Coffee & Churros', section: 'Sec 204', tier: 'Level 2', type: 'Cafe & Sweets', waitMin: 4, dietary: ['Vegetarian', 'Fair Trade'], signature: 'Organic Maple Latte ($6 CAD), Cinnamon Churros ($8 CAD)' },
    ],
    accessibilityHubs: [
      { id: 'acc1', name: 'KultureCity Certified Sensory Room', section: 'Sec 218', desc: 'Dedicated sensory calming zone equipped with bubble tubes, tactile panels & bean bag loungers.' },
      { id: 'acc2', name: 'Wheelchair Direct Level Access', section: 'Gate B & Gate A', desc: 'Seamless grade ramp entrances leading directly to concourses without escalators.' },
      { id: 'acc3', name: 'Descriptive Audio & French Translation', section: 'Guest Services Sec 208', desc: 'Bilingual live French/English descriptive audio headsets for accessibility.' },
    ],
    transitOptions: [
      { type: 'SkyTrain', name: 'Stadium-Chinatown Station (Expo Line)', eta: 'Trains every 2-3 mins to Waterfront & Surrey', status: 'Moderate Flow' },
      { type: 'Ferry', name: 'False Creek Aquabus / Ferry', eta: 'Scenic cross-bay ferry from Granville Island to BC Place dock', status: 'On-Schedule' },
      { type: 'Bus', name: 'TransLink Special Match Shuttle 250', eta: 'Express bus service to North Vancouver', status: 'Light Traffic' },
    ],
    upcomingMatch: {
      fixture: 'FIFA World Cup 2026 - Canada Group Match',
      date: 'Thursday, June 18, 2026',
      time: '18:00 PDT',
      teams: 'Canada vs Opponent Group B',
      projectedAttendance: 54500
    }
  }
};

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸 / 🇨🇦' },
  { code: 'es', name: 'Español', flag: '🇲🇽 / 🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷 / 🇨🇦' },
  { code: 'pt', name: 'Português', flag: '🇧🇷 / 🇵🇹' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦 / 🇲🇦' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
];

export const SAMPLE_WASTE_ITEMS = [
  {
    id: 'w1',
    name: 'Souvenir FIFA 2026 Beer Cup',
    category: 'Reusable / Plastic #5 PP',
    correctBin: 'Recycle (or Keep as Souvenir)',
    co2Saved: '140g CO2e',
    tip: 'Wash and keep! Or dispose in the Blue Recyclable Plastics bin. Do NOT throw in food compost.',
    imageIcon: '🥤'
  },
  {
    id: 'w2',
    name: 'Greasy Cardboard Pizza / Nacho Boat',
    category: 'Soiled Paper Packaging',
    correctBin: 'Compost (Organics)',
    co2Saved: '95g CO2e',
    tip: 'Because of cheese and food oils, this cannot be recycled as clean paper. Place in the Green Compost Bin!',
    imageIcon: '🍕'
  },
  {
    id: 'w3',
    name: 'Aluminum Soda / Seltzer Can',
    category: 'Metal & Aluminum',
    correctBin: 'Recycle',
    co2Saved: '220g CO2e',
    tip: '100% endlessly recyclable. Empty any liquid before dropping in the Blue Recycling Bin.',
    imageIcon: '🥫'
  },
  {
    id: 'w4',
    name: 'Bio-Polymer Compostable Fork & Knife',
    category: 'Certified PLA Bioplastic',
    correctBin: 'Compost (Organics)',
    co2Saved: '60g CO2e',
    tip: 'Made from industrial corn starch. Melts into organic fertilizer in stadium digesters within 45 days.',
    imageIcon: '🍴'
  },
  {
    id: 'w5',
    name: 'Single-Use Condiment Foil Sachet (Ketchup/Mayo)',
    category: 'Multi-layer Foil Plastic',
    correctBin: 'Landfill',
    co2Saved: '0g (Opt for bulk pump next time!)',
    tip: 'Multi-material plastic-foil cannot be mechanically sorted. Next time, use the pump dispensers at Concourse Kiosks!',
    imageIcon: '🍟'
  }
];
