import React, { useState } from 'react';
import Navbar from './components/Navbar';
import FanHub from './components/fan/FanHub';
import OpsCommandCenter from './components/ops/OpsCommandCenter';
import HackathonPitchModal from './components/presentation/HackathonPitchModal';
import { STADIUMS } from './data/stadiums';
import { Trophy, Heart, Sparkles, Shield, GitBranch } from 'lucide-react';

export default function App() {
  const [activeMode, setActiveMode] = useState('fan'); // 'fan' | 'ops'
  const [selectedStadium, setSelectedStadium] = useState(STADIUMS.metlife);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [accessibleMode, setAccessibleMode] = useState(false);
  const [showPitchModal, setShowPitchModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-slate-950">
      {/* Navigation Bar */}
      <Navbar
        activeMode={activeMode}
        setActiveMode={setActiveMode}
        selectedStadium={selectedStadium}
        setSelectedStadium={setSelectedStadium}
        stadiums={STADIUMS}
        currentLanguage={currentLanguage}
        setCurrentLanguage={setCurrentLanguage}
        accessibleMode={accessibleMode}
        setAccessibleMode={setAccessibleMode}
        onOpenPitchModal={() => setShowPitchModal(true)}
      />

      {/* Main Experience Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeMode === 'fan' ? (
          <FanHub
            stadium={selectedStadium}
            currentLanguage={currentLanguage}
            accessibleMode={accessibleMode}
          />
        ) : (
          <OpsCommandCenter
            stadium={selectedStadium}
          />
        )}
      </main>

      {/* Hackathon Pitch Modal */}
      {showPitchModal && (
        <HackathonPitchModal onClose={() => setShowPitchModal(false)} />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-8 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-slate-300">ArenaPulse 2026</span>
            <span>• Built for the FIFA World Cup 2026 GenAI Challenge</span>
          </div>

          <div className="flex items-center space-x-4 text-slate-400">
            <span>USA 🇺🇸 • MEX 🇲🇽 • CAN 🇨🇦</span>
            <span>•</span>
            <span className="text-emerald-400 font-semibold">Gemini 1.5 Flash Enabled</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
