import React, { useState } from 'react';
import { 
  Navigation, 
  Layers, 
  MapPin, 
  Clock, 
  Accessibility, 
  Utensils, 
  ShieldAlert, 
  ChevronRight,
  Info,
  Compass,
  Zap
} from 'lucide-react';

export default function InteractiveMap({ stadium, accessibleMode }) {
  const [selectedGate, setSelectedGate] = useState('z-a');
  const [selectedDestination, setSelectedDestination] = useState('c1');
  const [activeLayer, setActiveLayer] = useState('all'); // 'all', 'gates', 'concessions', 'accessibility'
  const [routeCalculated, setRouteCalculated] = useState(false);

  // SVG coordinates for stadium POIs
  const poiCoordinates = {
    'z-a': { x: 80, y: 250, label: 'Gate A (West)', type: 'gate' },
    'z-b': { x: 170, y: 70, label: 'Gate B (Northwest)', type: 'gate' },
    'z-c': { x: 330, y: 70, label: 'Gate C (Northeast)', type: 'gate' },
    'z-d': { x: 420, y: 250, label: 'Gate D (East)', type: 'gate' },
    'z-e': { x: 250, y: 430, label: 'Gate E (South)', type: 'gate' },
    'c1': { x: 140, y: 190, label: stadium.concessions[0]?.name || 'Concession 1', type: 'food' },
    'c2': { x: 360, y: 190, label: stadium.concessions[1]?.name || 'Concession 2', type: 'food' },
    'c3': { x: 250, y: 110, label: stadium.concessions[2]?.name || 'Concession 3', type: 'food' },
    'c4': { x: 150, y: 320, label: stadium.concessions[3]?.name || 'Concession 4', type: 'food' },
    'acc1': { x: 200, y: 150, label: 'Quiet Sensory Calm Room', type: 'acc' },
    'acc2': { x: 300, y: 330, label: 'ADA Express Elevator Bank', type: 'acc' },
  };

  const startCoord = poiCoordinates[selectedGate] || poiCoordinates['z-a'];
  const endCoord = poiCoordinates[selectedDestination] || poiCoordinates['c1'];

  // Midpoints for step-free route vs direct route
  const pathD = accessibleMode
    ? `M ${startCoord.x} ${startCoord.y} Q 250 250 ${endCoord.x} ${endCoord.y}`
    : `M ${startCoord.x} ${startCoord.y} L ${endCoord.x} ${endCoord.y}`;

  const calculateRoute = () => {
    setRouteCalculated(true);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Compass className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white font-display">
              Interactive 2.5D Stadium Wayfinder & Heatmap
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Real-time concourse routing, queue monitoring, and accessible path guidance for {stadium.name}
          </p>
        </div>

        {/* Filter Layers */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveLayer('all')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              activeLayer === 'all' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All POIs
          </button>
          <button
            onClick={() => setActiveLayer('gates')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              activeLayer === 'gates' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Gates
          </button>
          <button
            onClick={() => setActiveLayer('concessions')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              activeLayer === 'concessions' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Food & Halal
          </button>
          <button
            onClick={() => setActiveLayer('accessibility')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              activeLayer === 'accessibility' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Sensory / ADA
          </button>
        </div>
      </div>

      {/* Main Container: Map SVG + Route Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-4">
        {/* SVG Stadium Map Canvas */}
        <div className="lg:col-span-2 relative bg-slate-950 border border-slate-800 rounded-xl overflow-hidden p-4 flex flex-col items-center justify-center min-h-[460px]">
          {/* Status Overlay Banner */}
          <div className="absolute top-3 left-3 z-10 flex items-center space-x-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-xl text-xs backdrop-blur-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-slate-300 font-semibold">Live Concourse Telemetry Active</span>
          </div>

          {accessibleMode && (
            <div className="absolute top-3 right-3 z-10 bg-amber-500/20 border border-amber-500/40 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5">
              <Accessibility className="w-4 h-4 text-amber-400" />
              <span>Step-Free ADA Routing Enabled</span>
            </div>
          )}

          {/* SVG Stadium Canvas */}
          <svg viewBox="0 0 500 500" className="w-full max-w-[480px] h-auto drop-shadow-2xl">
            {/* Outer Concourse Ring */}
            <ellipse cx="250" cy="250" rx="220" ry="200" fill="#0B132B" stroke="#1E293B" strokeWidth="4" />
            <ellipse cx="250" cy="250" rx="180" ry="160" fill="#0F172A" stroke="#334155" strokeWidth="2" strokeDasharray="6 6" />
            <ellipse cx="250" cy="250" rx="140" ry="120" fill="#1E293B" stroke="#475569" strokeWidth="2" />

            {/* Stadium Pitch / Field */}
            <rect x="180" y="190" width="140" height="120" rx="8" fill="#064E3B" stroke="#10B981" strokeWidth="2.5" />
            {/* Center Circle */}
            <circle cx="250" cy="250" r="28" fill="none" stroke="#34D399" strokeWidth="1.5" />
            {/* Halfway Line */}
            <line x1="250" y1="190" x2="250" y2="310" stroke="#34D399" strokeWidth="1.5" />
            {/* Penalty boxes */}
            <rect x="180" y="220" width="22" height="60" fill="none" stroke="#34D399" strokeWidth="1.5" />
            <rect x="298" y="220" width="22" height="60" fill="none" stroke="#34D399" strokeWidth="1.5" />

            {/* Gate Density Heat Visualizers */}
            {stadium.zones.map(zone => {
              const coord = poiCoordinates[zone.id];
              if (!coord) return null;
              const isSurging = zone.status === 'surging';
              const isModerate = zone.status === 'moderate';

              return (
                <g key={zone.id}>
                  {/* Heat glow ring */}
                  <circle
                    cx={coord.x}
                    cy={coord.y}
                    r={isSurging ? 28 : isModerate ? 22 : 16}
                    fill={isSurging ? 'rgba(239, 68, 68, 0.25)' : isModerate ? 'rgba(245, 158, 11, 0.2)' : 'rgba(16, 185, 129, 0.15)'}
                    className={isSurging ? 'animate-pulse' : ''}
                  />
                  {/* Gate Anchor Point */}
                  <circle
                    cx={coord.x}
                    cy={coord.y}
                    r="12"
                    fill={isSurging ? '#EF4444' : isModerate ? '#F59E0B' : '#10B981'}
                    stroke="#020617"
                    strokeWidth="2.5"
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => setSelectedGate(zone.id)}
                  />
                  <text
                    x={coord.x}
                    y={coord.y + (coord.y > 250 ? 25 : -18)}
                    fill="#E2E8F0"
                    fontSize="10"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {zone.name.split('-')[0].trim()} ({zone.queueMin}m)
                  </text>
                </g>
              );
            })}

            {/* Concession / Food Icons */}
            {(activeLayer === 'all' || activeLayer === 'concessions') && stadium.concessions.map((c, idx) => {
              const coord = poiCoordinates[c.id];
              if (!coord) return null;
              return (
                <g key={c.id} className="cursor-pointer" onClick={() => setSelectedDestination(c.id)}>
                  <circle cx={coord.x} cy={coord.y} r="10" fill="#3B82F6" stroke="#FFFFFF" strokeWidth="1.5" />
                  <text x={coord.x} y={coord.y + 4} fill="#FFFFFF" fontSize="8" fontWeight="bold" textAnchor="middle">🍴</text>
                  <text x={coord.x} y={coord.y + 18} fill="#93C5FD" fontSize="9" textAnchor="middle" fontWeight="600">
                    {c.section} ({c.waitMin}m)
                  </text>
                </g>
              );
            })}

            {/* Accessibility POIs */}
            {(activeLayer === 'all' || activeLayer === 'accessibility') && (
              <>
                {/* Sensory Calm Room */}
                <g className="cursor-pointer" onClick={() => setSelectedDestination('acc1')}>
                  <circle cx="200" cy="150" r="11" fill="#8B5CF6" stroke="#FFFFFF" strokeWidth="1.5" />
                  <text x="200" y="154" fill="#FFFFFF" fontSize="9" textAnchor="middle">🧘</text>
                  <text x="200" y="168" fill="#DDD6FE" fontSize="8" textAnchor="middle" fontWeight="bold">Sensory Room</text>
                </g>
                {/* ADA Elevator */}
                <g className="cursor-pointer" onClick={() => setSelectedDestination('acc2')}>
                  <circle cx="300" cy="330" r="11" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="1.5" />
                  <text x="300" y="334" fill="#000000" fontSize="9" textAnchor="middle" fontWeight="bold">♿</text>
                  <text x="300" y="348" fill="#FDE68A" fontSize="8" textAnchor="middle" fontWeight="bold">ADA Elevator</text>
                </g>
              </>
            )}

            {/* Render Calculated Dynamic Wayfinding Route */}
            {routeCalculated && (
              <g>
                <path
                  d={pathD}
                  fill="none"
                  stroke={accessibleMode ? '#F59E0B' : '#00E676'}
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray="6 6"
                  className="animate-pulse"
                />
                <circle cx={startCoord.x} cy={startCoord.y} r="7" fill="#00E676" stroke="#000" strokeWidth="2" />
                <circle cx={endCoord.x} cy={endCoord.y} r="8" fill="#EF4444" stroke="#FFF" strokeWidth="2" />
              </g>
            )}
          </svg>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-3 text-[11px] text-slate-400">
            <span className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>Smooth (&lt;5m)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>Moderate (5-12m)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span>Critical Surge (&gt;15m)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
              <span>Concession / Halal</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
              <span>Sensory Calm Room</span>
            </span>
          </div>
        </div>

        {/* Route Planning & Turn-by-Turn Guidance Panel */}
        <div className="space-y-4">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Navigation className="w-4 h-4 text-emerald-400" />
              <span>Smart Pathfinding & Route Planner</span>
            </h3>

            {/* From Gate Selector */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                From Starting Gate:
              </label>
              <select
                value={selectedGate}
                onChange={(e) => {
                  setSelectedGate(e.target.value);
                  setRouteCalculated(false);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-emerald-500"
              >
                {stadium.zones.map(z => (
                  <option key={z.id} value={z.id}>
                    {z.name} ({z.queueMin} min queue)
                  </option>
                ))}
              </select>
            </div>

            {/* Destination Selector */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                To Destination / Facility:
              </label>
              <select
                value={selectedDestination}
                onChange={(e) => {
                  setSelectedDestination(e.target.value);
                  setRouteCalculated(false);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-emerald-500"
              >
                <optgroup label="Concessions & Dietary">
                  {stadium.concessions.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.section} - {c.waitMin}m wait)
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Accessibility & Inclusion">
                  <option value="acc1">Quiet Sensory Calm Room (Sec 118)</option>
                  <option value="acc2">ADA Express Elevators (Bank 2)</option>
                </optgroup>
              </select>
            </div>

            {/* Calculate Button */}
            <button
              onClick={calculateRoute}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-md shadow-emerald-500/20 transition-all"
            >
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>Calculate Optimal AI Route</span>
            </button>
          </div>

          {/* Turn-by-Turn Result Card */}
          {routeCalculated ? (
            <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/30 space-y-2.5 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 flex items-center space-x-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Est. Walk Time: 3 mins (240m)</span>
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                  {accessibleMode ? '♿ 100% Step-Free' : '⚡ Fastest Path'}
                </span>
              </div>

              <div className="space-y-2 text-xs text-slate-300 divide-y divide-slate-850">
                <div className="flex items-start space-x-2 pt-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0">1</span>
                  <span>Exit {poiCoordinates[selectedGate]?.label} turnstiles through Concourse Outer Ring.</span>
                </div>
                <div className="flex items-start space-x-2 pt-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0">2</span>
                  <span>
                    {accessibleMode
                      ? 'Follow ADA Yellow Tactile floor paving directly to Elevator Bank 2 (avoid staircase 4).'
                      : 'Follow Main Concourse corridor past merchandise pavilion.'}
                  </span>
                </div>
                <div className="flex items-start space-x-2 pt-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0">3</span>
                  <span>Arrive at {poiCoordinates[selectedDestination]?.label}. Look for the overhead LED locator beacon.</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 text-center text-xs text-slate-400">
              Select your entry gate and destination above, then tap <strong>Calculate Optimal AI Route</strong> for turn-by-turn navigation.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
