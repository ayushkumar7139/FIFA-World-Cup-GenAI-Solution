import React, { useState } from 'react';
import { 
  X, 
  Tv2, 
  CheckCircle2, 
  FileText, 
  Copy, 
  Layers, 
  GitBranch, 
  Sparkles, 
  Video, 
  Trophy,
  ExternalLink
} from 'lucide-react';

export default function HackathonPitchModal({ onClose }) {
  const [activePitchTab, setActivePitchTab] = useState('script'); // 'script', 'architecture', 'submission'
  const [copied, setCopied] = useState(false);

  const videoScript = `[0:00 - 0:25] THE HOOK & THE PROBLEM:
"Welcome! The FIFA World Cup 2026 will be the largest sporting event in human history: 3 host countries, 16 stadiums, 48 teams, and over 6 million international fans. But massive 80,000-seat stadiums face unprecedented bottlenecks: dangerous gate surges, multi-language communication barriers, complex accessibility challenges for neurodivergent & disabled fans, and thousands of tons of matchday packaging waste.

Enter ArenaPulse 2026: An end-to-end Generative AI stadium operating system and fan companion that turns matchday chaos into an orchestrated, inclusive, and sustainable experience."

[0:25 - 1:15] LIVE DEMO 1: FAN EXPERIENCE & MULTI-AGENT CONCIERGE:
"On the fan side, MatchVoice AI acts as a 24/7 multilingual stadium concierge supporting 10+ languages. Watch as I ask for the nearest Halal food with low wait times: the AI calculates real-time queue data across concessions, highlights Section 114, and provides dietary verification.

Next, our Interactive 2.5D Stadium Wayfinder features Universal Accessibility Mode. Toggling ADA mode instantly reroutes pathfinding away from stairs directly to wheelchair elevators and quiet sensory rooms.

For sustainability, our GenAI EcoVision scanner uses multimodal vision to analyze matchday cups, cans, and food packaging, identifying the exact disposal bin and awarding fans Green Pass reward points!"

[1:15 - 2:05] LIVE DEMO 2: OPS COMMAND CENTER & GENAI INCIDENT COMMANDER:
"Now let's flip to Ops Command for venue staff and tournament organizers. Here, real-time turnstile telemetry tracks inflow across all perimeter gates.

Notice Gate C is experiencing a severe crowd bottleneck. With one click, our GenAI Incident Commander synthesizes a 5-step Tactical SOP, allocates 14 marshals and volunteers, and auto-generates a trilingual Stadium PA broadcast script in English, Spanish, and French that broadcasts directly through the venue sound system!

Simultaneously, the Dynamic Gate Balancer redistributes foot traffic, cutting peak wait times by 66%."

[2:05 - 2:40] TECH STACK & ARCHITECTURE:
"ArenaPulse 2026 is powered by Google Gemini 1.5 Flash models for ultra-low latency multi-agent orchestration, combined with a lightweight React 18, Vite, and Tailwind CSS frontend that weighs under 3 MB, perfectly meeting strict repository size requirements."

[2:40 - 3:00] CONCLUSION & CALL TO ACTION:
"ArenaPulse isn't just an app—it's the digital nervous system for the modern mega-event. Thank you, and see you at the FIFA World Cup 2026!"`;

  const copyScript = () => {
    navigator.clipboard.writeText(videoScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-purple-900/30">
              <Tv2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                Hackathon Presentation & Video Demo Kit
              </h2>
              <p className="text-xs text-slate-400">Everything needed for an exceptional hackathon submission</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Ribbon */}
        <div className="bg-slate-950/60 px-6 py-2.5 border-b border-slate-800 flex items-center space-x-2 text-xs">
          <button
            onClick={() => setActivePitchTab('script')}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl font-bold transition-colors ${
              activePitchTab === 'script' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>3-Minute Video Pitch Script</span>
          </button>
          <button
            onClick={() => setActivePitchTab('architecture')}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl font-bold transition-colors ${
              activePitchTab === 'architecture' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Architecture & GenAI Pillars</span>
          </button>
          <button
            onClick={() => setActivePitchTab('submission')}
            className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl font-bold transition-colors ${
              activePitchTab === 'submission' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>Submission Checklist (&lt;10 MB)</span>
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activePitchTab === 'script' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Ready-to-record timed script for your YouTube or Google Drive submission video.
                </span>
                <button
                  onClick={copyScript}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied to Clipboard!' : 'Copy Script'}</span>
                </button>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 font-mono text-xs sm:text-[13px] text-slate-300 whitespace-pre-wrap leading-relaxed select-all">
                {videoScript}
              </div>
            </div>
          )}

          {activePitchTab === 'architecture' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white">GenAI Solution Architecture</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="font-bold text-emerald-400 flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Layer 1: Sensor & Stadium Graph</span>
                  </div>
                  <p className="text-slate-300">
                    Real-time turnstile throughput rates, dietary concession inventories, accessibility hubs, and transit connections across USA, Mexico, and Canada.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="font-bold text-blue-400 flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Layer 2: Multi-Agent GenAI Engine</span>
                  </div>
                  <p className="text-slate-300">
                    Powered by Google Gemini models with multi-agent roles: Concierge Guide, ADA Specialist, Transit Navigator, Incident Commander, and EcoVision Classifier.
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="font-bold text-purple-400 flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Layer 3: Dual-Mode Experience Hub</span>
                  </div>
                  <p className="text-slate-300">
                    Fan Experience Hub with Web Speech audio and 2.5D SVG interactive wayfinding + Operations Command Center with automated SOP generator and trilingual PA broadcast.
                  </p>
                </div>
              </div>

              {/* Pillars Covered */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Mandatory Hackathon Pillars Fulfilled:
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Navigation & Wayfinding</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Crowd Management</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Universal Accessibility</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Smart Transportation</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Sustainability (EcoVision)</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Multilingual (10+ Langs)</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Operational Intelligence</div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-emerald-400 font-bold">✓ Real-Time Decision Support</div>
                </div>
              </div>
            </div>
          )}

          {activePitchTab === 'submission' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white">Submission Verification Checklist</h3>

              <div className="space-y-2.5 text-xs">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30 flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">Repository Size &lt; 10 MB</div>
                    <p className="text-slate-400 mt-0.5">
                      Strict <code>.gitignore</code> in place. Total repo size is approximately <strong>~1.5 MB</strong> (excluding node_modules). 100% compliant with the &lt; 10 MB constraint!
                    </p>
                  </div>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30 flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">Public Access Requirement</div>
                    <p className="text-slate-400 mt-0.5">
                      Ensure your GitHub repository visibility is set to <strong>Public</strong>. (Restricted / Private links cannot be evaluated).
                    </p>
                  </div>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30 flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">Video Link (YouTube Unlisted or Google Drive)</div>
                    <p className="text-slate-400 mt-0.5">
                      Upload your 2-3 minute screen recording to YouTube (set to "Unlisted") or Google Drive (ensure "Anyone with the link can view" permission is enabled).
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            FIFA World Cup 2026 GenAI Stadium Challenge
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Close Deck
          </button>
        </div>
      </div>
    </div>
  );
}
