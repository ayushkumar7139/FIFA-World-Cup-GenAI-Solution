import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Activity, 
  ShieldAlert, 
  Shuffle, 
  Radio, 
  Users, 
  CheckSquare, 
  Sparkles,
  ExternalLink
} from 'lucide-react';

import CrowdTelemetry from './CrowdTelemetry';
import GenAIIncidentCommander from './GenAIIncidentCommander';
import DynamicRerouting from './DynamicRerouting';

export default function OpsCommandCenter({ stadium }) {
  const [activeOpsTab, setActiveOpsTab] = useState('telemetry');

  const opsTabs = [
    { id: 'telemetry', name: 'Crowd & Gate Telemetry', icon: Activity, badge: 'Live Stream' },
    { id: 'incident', name: 'GenAI Incident Commander', icon: ShieldAlert, badge: 'SOP Copilot' },
    { id: 'rerouting', name: 'Dynamic Gate Balancer', icon: Shuffle, badge: 'Predictive' },
  ];

  return (
    <div className="space-y-6">
      {/* Ops Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 p-6 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl">{stadium.flag}</span>
              <span className="text-xs font-extrabold uppercase tracking-widest text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full border border-blue-500/20">
                Operations & Venue Command OS
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
              {stadium.name} — Command Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              Real-time operational intelligence, tactical volunteer dispatch, and crowd safety decision support.
            </p>
          </div>

          {/* Quick Ops Metrics */}
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex items-center space-x-4 text-xs">
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Staff on Duty</div>
              <div className="text-base font-extrabold text-white">418 Active Marshals</div>
            </div>
            <div className="h-8 w-px bg-slate-800"></div>
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Volunteers</div>
              <div className="text-base font-extrabold text-teal-300">320 In-Sector</div>
            </div>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          {opsTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeOpsTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveOpsTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 scale-[1.02]'
                    : 'bg-slate-900/60 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.name}</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${
                  isActive ? 'bg-slate-950/40 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {tab.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Tab View */}
      <div className="transition-all duration-200">
        {activeOpsTab === 'telemetry' && <CrowdTelemetry stadium={stadium} />}
        {activeOpsTab === 'incident' && <GenAIIncidentCommander stadium={stadium} />}
        {activeOpsTab === 'rerouting' && <DynamicRerouting stadium={stadium} />}
      </div>
    </div>
  );
}
