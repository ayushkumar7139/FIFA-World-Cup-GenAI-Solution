import React, { useState } from 'react';
import { 
  Recycle, 
  Sparkles, 
  Leaf, 
  Award, 
  Camera, 
  CheckCircle, 
  AlertTriangle, 
  TrendingUp, 
  Flame,
  HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SAMPLE_WASTE_ITEMS } from '../../data/stadiums';
import { classifyWasteItemWithAI } from '../../services/geminiService';

export default function EcoVisionScanner({ stadium }) {
  const [selectedSample, setSelectedSample] = useState(SAMPLE_WASTE_ITEMS[0]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [greenPoints, setGreenPoints] = useState(140);
  const [totalCo2Saved, setTotalCo2Saved] = useState(680); // in grams

  const handleScan = async (sample = selectedSample) => {
    setIsScanning(true);
    setScanResult(null);

    try {
      const result = await classifyWasteItemWithAI({
        sampleItem: sample
      });
      setScanResult(result);
      setGreenPoints(prev => prev + result.greenPointsEarned);
      setTotalCo2Saved(prev => prev + parseInt(result.co2Saved) || 120);

      // Trigger celebratory confetti
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#00E676', '#10B981', '#FFD700', '#3B82F6']
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Leaf className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white font-display">
              GenAI EcoVision: Zero-Waste Stadium Scanner
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Multimodal AI classification to divert matchday packaging from landfills at {stadium.name}
          </p>
        </div>

        {/* Fan Sustainability Stats */}
        <div className="flex items-center space-x-3 bg-slate-950 px-3.5 py-2 rounded-xl border border-emerald-500/30">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Your Green Pass</div>
            <div className="text-xs font-extrabold text-emerald-400 flex items-center justify-end space-x-1">
              <Award className="w-3.5 h-3.5 text-yellow-400" />
              <span>{greenPoints} Points</span>
            </div>
          </div>
          <div className="h-6 w-px bg-slate-800"></div>
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">CO₂ Diverted</div>
            <div className="text-xs font-extrabold text-teal-300">{(totalCo2Saved / 1000).toFixed(2)} kg</div>
          </div>
        </div>
      </div>

      {/* Main Interactive Scanner Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sample Item Selection / Camera View */}
        <div className="space-y-4">
          <label className="text-xs font-bold text-slate-300 flex items-center space-x-2">
            <Camera className="w-4 h-4 text-emerald-400" />
            <span>Select Matchday Packaging Item to Scan:</span>
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {SAMPLE_WASTE_ITEMS.map((item) => {
              const isSelected = selectedSample.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedSample(item);
                    setScanResult(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-2xl mb-2">{item.imageIcon}</div>
                  <div>
                    <div className="text-xs font-bold truncate text-slate-200">{item.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{item.category}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Scanner Action Button */}
          <button
            onClick={() => handleScan(selectedSample)}
            disabled={isScanning}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:brightness-110 disabled:opacity-50 text-slate-950 font-extrabold rounded-xl text-sm flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
          >
            {isScanning ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin text-slate-950" />
                <span>Multimodal Neural Vision Analyzing Item...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 fill-current text-slate-950" />
                <span>Scan "{selectedSample.name}" with GenAI Vision</span>
              </>
            )}
          </button>

          <p className="text-[11px] text-slate-400 text-center">
            *Powered by Gemini 1.5 Flash multimodal image & material decomposition reasoning.
          </p>
        </div>

        {/* Scan Results Card */}
        <div>
          {scanResult ? (
            <div className="bg-slate-950 border border-emerald-500/40 rounded-xl p-5 space-y-4 animate-in fade-in zoom-in-95 duration-200 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-850">
                <div className="flex items-center space-x-2.5">
                  <span className="text-3xl">{selectedSample.imageIcon}</span>
                  <div>
                    <h3 className="text-sm font-bold text-white">{scanResult.name}</h3>
                    <span className="text-[11px] text-emerald-400 font-medium">Confidence: {scanResult.confidenceScore}%</span>
                  </div>
                </div>
                <div className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
                  <span>+{scanResult.greenPointsEarned} pts</span>
                </div>
              </div>

              {/* Destination Bin Callout */}
              <div className={`p-4 rounded-xl border flex items-center space-x-3 ${
                scanResult.correctBin.includes('Compost') 
                  ? 'bg-emerald-950/40 border-emerald-600/40 text-emerald-200' 
                  : scanResult.correctBin.includes('Recycle')
                  ? 'bg-blue-950/40 border-blue-600/40 text-blue-200'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}>
                <div className={`p-2.5 rounded-xl ${
                  scanResult.correctBin.includes('Compost')
                    ? 'bg-emerald-500 text-slate-950'
                    : scanResult.correctBin.includes('Recycle')
                    ? 'bg-blue-500 text-white'
                    : 'bg-slate-700 text-white'
                }`}>
                  <Recycle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider font-extrabold opacity-75">Target Stadium Disposal Bin</div>
                  <div className="text-base font-extrabold">{scanResult.correctBin}</div>
                </div>
              </div>

              {/* AI Reasoning & Tips */}
              <div className="space-y-2 text-xs">
                <div className="text-slate-300 leading-relaxed bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="font-bold text-emerald-400">🤖 AI Material Analysis: </span>
                  {scanResult.aiReasoning}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block font-semibold">CO₂ Offset:</span>
                    <span className="text-emerald-300 font-bold">{scanResult.co2Saved}</span>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block font-semibold">Decomposition:</span>
                    <span className="text-teal-300 font-bold">{scanResult.decompositionTime}</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[300px] bg-slate-950/50 border border-dashed border-slate-800 rounded-xl flex flex-col items-center justify-center p-6 text-center text-slate-400">
              <Leaf className="w-10 h-10 text-slate-600 mb-3" />
              <h4 className="text-sm font-bold text-slate-300">Zero-Waste AI Scanner Ready</h4>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Select any matchday container from the left to test real-time multimodal material classification and earn Green World Cup fan points!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
