import React, { useState } from 'react';
import { 
  GitFork, 
  ArrowRight, 
  TrendingDown, 
  CheckCircle2, 
  Sparkles, 
  Clock, 
  AlertTriangle,
  Shuffle
} from 'lucide-react';

export default function DynamicRerouting({ stadium }) {
  const [isBalancing, setIsBalancing] = useState(false);
  const [balancedState, setBalancedState] = useState(false);

  const initialGates = [
    { name: 'Gate A (West Plaza)', currentWait: 4, capacity: '42%', status: 'optimal' },
    { name: 'Gate B (Verizon West)', currentWait: 2, capacity: '28%', status: 'underutilized' },
    { name: 'Gate C (North Plaza)', currentWait: 18, capacity: '96%', status: 'surging' },
    { name: 'Gate D (East Concourse)', currentWait: 11, capacity: '78%', status: 'moderate' },
  ];

  const balancedGates = [
    { name: 'Gate A (West Plaza)', currentWait: 5, capacity: '52%', status: 'optimal' },
    { name: 'Gate B (Verizon West)', currentWait: 5, capacity: '56%', status: 'optimal' },
    { name: 'Gate C (North Plaza)', currentWait: 6, capacity: '58%', status: 'optimal' },
    { name: 'Gate D (East Concourse)', currentWait: 6, capacity: '60%', status: 'optimal' },
  ];

  const handleRunBalancer = () => {
    setIsBalancing(true);
    setTimeout(() => {
      setIsBalancing(false);
      setBalancedState(true);
    }, 900);
  };

  const handleReset = () => {
    setBalancedState(false);
  };

  const currentDisplayGates = balancedState ? balancedGates : initialGates;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Shuffle className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white font-display">
              AI Crowd Redistribution & Dynamic Gate Balancer
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Automated load balancing algorithm redirecting arrival waves to eliminate queue bottlenecks
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {balancedState ? (
            <button
              onClick={handleReset}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700"
            >
              Reset Simulation
            </button>
          ) : (
            <button
              onClick={handleRunBalancer}
              disabled={isBalancing}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 rounded-xl text-xs font-extrabold flex items-center space-x-1.5 shadow-md shadow-emerald-500/20"
            >
              {isBalancing ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>Computing Optimal Distribution...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  <span>Execute AI Dynamic Rerouting</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Rerouting Impact Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="text-[10px] font-bold uppercase text-slate-400">Max Bottleneck Queue</div>
          <div className="text-2xl font-extrabold text-white mt-1 flex items-baseline space-x-2">
            <span className={balancedState ? 'text-emerald-400' : 'text-rose-400'}>
              {balancedState ? '6 mins' : '18 mins'}
            </span>
            {balancedState && (
              <span className="text-xs font-bold text-emerald-400 flex items-center">
                <TrendingDown className="w-3.5 h-3.5 mr-0.5" /> -66% reduction
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {balancedState ? 'No gate exceeds safe 7-minute threshold' : 'Gate C turnstile backlog exceeds safety threshold'}
          </p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="text-[10px] font-bold uppercase text-slate-400">Fans Rerouted</div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {balancedState ? '3,450 Fans' : '0 Fans (Idle)'}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {balancedState ? 'Dispersed via mobile push & digital signage' : 'Turnstiles operating unevenly'}
          </p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="text-[10px] font-bold uppercase text-slate-400">Safety Risk Index</div>
          <div className="text-2xl font-extrabold text-white mt-1 flex items-center space-x-1.5">
            <span className={balancedState ? 'text-emerald-400' : 'text-amber-400'}>
              {balancedState ? 'Low (Level 1)' : 'Elevated (Level 3)'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {balancedState ? 'Zero crowd crushes or choke points' : 'High crush density at North turnstiles'}
          </p>
        </div>
      </div>

      {/* Visual Gate Balance Gauges */}
      <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-4">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Gate Capacity & Queue Balancing
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {currentDisplayGates.map((gate, idx) => {
            const isSurge = gate.currentWait > 12;
            const isOptimal = gate.status === 'optimal';

            return (
              <div key={idx} className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white truncate">{gate.name}</span>
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                    isSurge ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                    isOptimal ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                    'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {gate.currentWait} min wait
                  </span>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Turnstile Load:</span>
                    <span className="font-bold text-slate-200">{gate.capacity}</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        isSurge ? 'bg-rose-500' : isOptimal ? 'bg-emerald-500' : 'bg-amber-500'
                      }`}
                      style={{ width: gate.capacity }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
