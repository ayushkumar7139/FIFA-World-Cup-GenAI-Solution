import React, { useState } from 'react';
import { 
  Train, 
  Bus, 
  Car, 
  Bike, 
  Plane, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight, 
  MapPin, 
  Compass, 
  Shield 
} from 'lucide-react';

export default function SmartTransit({ stadium }) {
  const [selectedTransit, setSelectedTransit] = useState(stadium.transitOptions[0]);

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Train className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white font-display">
              Smart Transit & Cross-Border Mobility Guide
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Real-time public transit schedules, parking zones, and tri-nation airport connections for {stadium.name}
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-blue-950/40 border border-blue-800/40 px-3 py-1.5 rounded-xl text-xs text-blue-300">
          <Plane className="w-4 h-4 text-blue-400" />
          <span>Tri-Nation FIFA Transit Hub Active</span>
        </div>
      </div>

      {/* Transit Modes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stadium.transitOptions.map((opt, idx) => {
          const isSelected = selectedTransit.name === opt.name;
          return (
            <div
              key={idx}
              onClick={() => setSelectedTransit(opt)}
              className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-blue-500/10 border-blue-500 text-white shadow-lg shadow-blue-500/10'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    {opt.type === 'Rail' || opt.type === 'Train' || opt.type === 'SkyTrain' ? (
                      <Train className="w-4 h-4 text-emerald-400" />
                    ) : opt.type === 'Bus' || opt.type === 'Shuttle' ? (
                      <Bus className="w-4 h-4 text-blue-400" />
                    ) : opt.type === 'Rideshare' ? (
                      <Car className="w-4 h-4 text-purple-400" />
                    ) : (
                      <Bike className="w-4 h-4 text-teal-400" />
                    )}
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    opt.status === 'On-Schedule' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                    opt.status === 'Light Traffic' ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30' :
                    'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {opt.status}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white leading-snug">{opt.name}</h4>
                <p className="text-[11px] text-slate-400 mt-1">{opt.eta}</p>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-medium text-blue-400">
                <span>View Route Map</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Cross-Border & Airport Connections Banner */}
      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="space-y-1">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
            <Plane className="w-3.5 h-3.5 text-blue-400" />
            <span>Nearest International Airport</span>
          </div>
          <div className="font-bold text-white text-sm">
            {stadium.id === 'metlife' ? 'Newark Liberty (EWR) / JFK (NYC)' :
             stadium.id === 'azteca' ? 'Benito Juárez Int\'l (MEX)' :
             'Vancouver Int\'l Airport (YVR)'}
          </div>
          <p className="text-slate-400 text-[11px]">Direct express FIFA transit shuttles every 20 minutes.</p>
        </div>

        <div className="space-y-1">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>Cross-Border Transit Notice</span>
          </div>
          <div className="font-bold text-emerald-300">FIFA Fan ID Fast-Track Lanes Active</div>
          <p className="text-slate-400 text-[11px]">Pre-cleared mobile customs available via CBP One™ and ArriveCAN.</p>
        </div>

        <div className="space-y-1">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Post-Match Dispersal Wave</span>
          </div>
          <div className="font-bold text-amber-300">Peak Egress: 21:00 - 21:45</div>
          <p className="text-slate-400 text-[11px]">Free WiFi & live DJ performances in Concourse West until 22:30.</p>
        </div>
      </div>
    </div>
  );
}
