import git from 'isomorphic-git';
import fs from 'fs';
import path from 'path';

const dir = process.cwd();

async function main() {
  console.log('Initializing Git repository at:', dir);
  await git.init({ fs, dir, defaultBranch: 'main' });
  console.log('Git repo initialized successfully.');

  // List of files to stage
  const filesToStage = [
    'package.json',
    'package-lock.json',
    'vite.config.js',
    'tailwind.config.js',
    'postcss.config.js',
    'index.html',
    '.gitignore',
    '.env.example',
    'README.md',
    'LICENSE',
    'src/main.jsx',
    'src/App.jsx',
    'src/index.css',
    'src/data/stadiums.js',
    'src/services/geminiService.js',
    'src/components/Navbar.jsx',
    'src/components/fan/FanHub.jsx',
    'src/components/fan/VoiceConcierge.jsx',
    'src/components/fan/InteractiveMap.jsx',
    'src/components/fan/EcoVisionScanner.jsx',
    'src/components/fan/SensoryAndAccessibility.jsx',
    'src/components/fan/SmartTransit.jsx',
    'src/components/ops/OpsCommandCenter.jsx',
    'src/components/ops/CrowdTelemetry.jsx',
    'src/components/ops/GenAIIncidentCommander.jsx',
    'src/components/ops/DynamicRerouting.jsx',
    'src/components/presentation/HackathonPitchModal.jsx'
  ];

  for (const filepath of filesToStage) {
    if (fs.existsSync(path.join(dir, filepath))) {
      await git.add({ fs, dir, filepath });
    }
  }
  console.log(`Staged ${filesToStage.length} source files.`);

  const sha = await git.commit({
    fs,
    dir,
    author: {
      name: 'FIFA Hackathon Submitter',
      email: 'fifa2026-submitter@arenapulse.internal',
    },
    message: 'Initial commit: ArenaPulse 2026 - FIFA World Cup GenAI Platform'
  });

  console.log('Created commit successfully! Commit SHA:', sha);
}

main().catch(err => {
  console.error('Error during git setup:', err);
  process.exit(1);
});
