import React, { useState, useEffect, useRef } from 'react';
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Compass, 
  Clock, 
  ShieldAlert, 
  HeartHandshake, 
  Train,
  CheckCircle2,
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { generateConciergeResponse } from '../../services/geminiService';

export default function VoiceConcierge({ stadium, currentLanguage, accessibleMode }) {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activePersona, setActivePersona] = useState('concierge');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);

  const messagesEndRef = useRef(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      setSpeechSupported(true);
    }

    // Set initial welcome message
    const welcome = {
      id: 'welcome',
      sender: 'bot',
      agentPersona: 'concierge',
      model: 'ArenaPulse Multi-Agent AI',
      timestamp: new Date().toLocaleTimeString(),
      text: `👋 **Welcome to ${stadium.name} for the FIFA World Cup 2026!**\n\nI'm your **ArenaPulse Matchday Concierge**. Ask me anything about:\n• 🍔 Dietary concessions (Halal, Kosher, Vegan, Allergen-free)\n• ♿ Wheelchair step-free routes & Sensory Calm Rooms\n• 🚪 Real-time gate queues & ticket scanning\n• 🚆 Post-match transit & regional shuttles\n\nHow can I help make your match experience unforgettable today?`
    };
    setMessages([welcome]);
  }, [stadium.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = async (customQuery = null) => {
    const query = customQuery || inputText;
    if (!query.trim() || isTyping) return;

    const userMsg = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    try {
      const response = await generateConciergeResponse({
        query,
        language: currentLanguage,
        stadium,
        persona: activePersona,
        accessibleMode
      });

      const botMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: response.text,
        agentPersona: response.agentPersona,
        model: response.model,
        actionCard: response.actionCard,
        timestamp: response.timestamp
      };

      setMessages(prev => [...prev, botMsg]);

      // Auto TTS if user used voice or wanted audio
      if (isListening) {
        speakText(response.text.replace(/[*#•_]/g, ''));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  // Web Speech Recognition
  const toggleVoiceInput = () => {
    if (!speechSupported) {
      alert('Speech recognition is not supported in this browser. Please use Chrome/Edge or type your question.');
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = currentLanguage === 'es' ? 'es-MX' : currentLanguage === 'fr' ? 'fr-FR' : 'en-US';
    recognition.interimResults = false;

    if (!isListening) {
      recognition.start();
      setIsListening(true);

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
        handleSend(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    } else {
      recognition.stop();
      setIsListening(false);
    }
  };

  // Text to Speech
  const speakText = (text) => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const cleanText = text.replace(/[*#•_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = currentLanguage === 'es' ? 'es-MX' : currentLanguage === 'fr' ? 'fr-FR' : 'en-US';
    utterance.rate = 1.0;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const samplePrompts = [
    { label: 'Nearest Halal Food (< 5 min wait)', query: 'Where can I find halal food with the shortest queue?' },
    { label: 'Step-Free Wheelchair Route', query: 'Show me the step-free accessible route to Section 114 from Gate A' },
    { label: 'Quiet Sensory Calm Room', query: 'Where is the quiet sensory room for fans with autism or sensory overload?' },
    { label: 'Fastest Post-Match Train', query: 'What is the fastest transit train to take right after full-time to avoid crowds?' },
    { label: 'FIFA Clear Bag Rules', query: 'What is the official FIFA 2026 stadium bag policy?' },
  ];

  return (
    <div className="flex flex-col h-[700px] bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl overflow-hidden backdrop-blur-sm">
      {/* Top Bar: Persona Selector & Status */}
      <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-sm font-bold text-white font-display">MatchVoice 2026</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Multi-Agent
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Contextualized for {stadium.name.split('(')[0]}</p>
          </div>
        </div>

        {/* Persona Tabs */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
          <button
            onClick={() => setActivePersona('concierge')}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition-all ${
              activePersona === 'concierge' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Concierge</span>
          </button>
          <button
            onClick={() => setActivePersona('accessibility')}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition-all ${
              activePersona === 'accessibility' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Accessibility</span>
          </button>
          <button
            onClick={() => setActivePersona('transit')}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition-all ${
              activePersona === 'transit' ? 'bg-blue-500 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Train className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Transit</span>
          </button>
        </div>
      </div>

      {/* Suggested Query Chips */}
      <div className="bg-slate-950/60 px-4 py-2 border-b border-slate-850 flex items-center space-x-2 overflow-x-auto no-scrollbar">
        <span className="text-[11px] font-semibold text-slate-500 flex items-center whitespace-nowrap">
          <Sparkles className="w-3 h-3 text-emerald-400 mr-1" /> Quick AI Ask:
        </span>
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p.query)}
            className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white whitespace-nowrap border border-slate-700/60 transition-colors"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div key={m.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-4 shadow-md ${
                isUser 
                  ? 'bg-emerald-600 text-white rounded-br-none' 
                  : 'bg-slate-800/90 border border-slate-700/80 text-slate-100 rounded-bl-none'
              }`}>
                {/* Bot header info */}
                {!isUser && (
                  <div className="flex items-center justify-between border-b border-slate-700/60 pb-2 mb-2 text-[11px] text-slate-400">
                    <div className="flex items-center space-x-1.5">
                      <span className="font-semibold text-emerald-400">
                        {m.agentPersona === 'accessibility' ? '♿ ADA Specialist' : m.agentPersona === 'transit' ? '🚆 Transit Agent' : '⚽ Stadium Guide'}
                      </span>
                      <span>•</span>
                      <span className="text-[10px] text-slate-400">{m.model || 'Gemini 1.5'}</span>
                    </div>
                    <button
                      onClick={() => speakText(m.text)}
                      title="Listen via Audio"
                      className="p-1 rounded hover:bg-slate-700 text-slate-300 hover:text-emerald-400 transition-colors"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Formatted Text Content */}
                <div className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed space-y-1">
                  {m.text.split('\n').map((line, lIdx) => {
                    if (line.startsWith('•') || line.startsWith('-')) {
                      return <div key={lIdx} className="pl-2">{line}</div>;
                    }
                    if (line.startsWith('**') || line.startsWith('⚽') || line.startsWith('♿') || line.startsWith('🚆')) {
                      return <div key={lIdx} className="font-bold text-slate-100">{line}</div>;
                    }
                    return <div key={lIdx}>{line}</div>;
                  })}
                </div>

                {/* Action Card if present */}
                {m.actionCard && (
                  <div className="mt-3 p-3 bg-slate-900/90 border border-emerald-500/30 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white">{m.actionCard.title}</div>
                      <div className="text-[11px] text-slate-400 flex items-center space-x-2 mt-0.5">
                        <span className="flex items-center text-emerald-400 font-medium">
                          <Clock className="w-3 h-3 mr-1" /> {m.actionCard.waitMin} min wait
                        </span>
                        <span>•</span>
                        <span>{m.actionCard.location}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => alert(`Navigating to ${m.actionCard.title} at ${m.actionCard.location}. Turn-by-turn guidance activated!`)}
                      className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs transition-colors flex items-center space-x-1"
                    >
                      <span>Route</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                )}

                <div className="text-[10px] text-slate-400 text-right mt-1.5">
                  {m.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-3 flex items-center space-x-2 text-xs text-slate-400">
              <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
              <span>PitchPulse AI is analyzing stadium sensors & venue graph...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Audio Speaking Status */}
      {isSpeaking && (
        <div className="bg-emerald-950/80 border-t border-emerald-800/40 px-4 py-1.5 flex items-center justify-between text-xs text-emerald-300">
          <div className="flex items-center space-x-2">
            <Volume2 className="w-3.5 h-3.5 animate-pulse" />
            <span>Reading response via Audio Assistant...</span>
          </div>
          <button
            onClick={() => {
              window.speechSynthesis.cancel();
              setIsSpeaking(false);
            }}
            className="text-[11px] underline text-emerald-400 hover:text-emerald-200"
          >
            Mute
          </button>
        </div>
      )}

      {/* Input Bar */}
      <div className="p-3.5 bg-slate-950 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-2"
        >
          {/* Voice Input Button */}
          <button
            type="button"
            onClick={toggleVoiceInput}
            title={isListening ? 'Listening... click to stop' : 'Click to Speak'}
            className={`p-2.5 rounded-xl border transition-all ${
              isListening
                ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            placeholder={
              accessibleMode
                ? "Ask accessible concierge (e.g., 'Elevator route to Sec 102', 'Sensory room', 'Halal food')..."
                : "Ask anything about tickets, gates, concessions, transit, or seats..."
            }
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />

          <button
            type="submit"
            disabled={!inputText.trim() || isTyping}
            className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold transition-all shadow-md shadow-emerald-500/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
