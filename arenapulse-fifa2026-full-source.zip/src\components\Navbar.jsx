import React, { useState } from 'react';
import { 
  Trophy, 
  ShieldCheck, 
  Users, 
  MapPin, 
  Globe2, 
  Accessibility, 
  Sparkles, 
  Key, 
  Tv2,
  AlertCircle
} from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../data/stadiums';
import { getStoredApiKey, setStoredApiKey } from '../services/geminiService';

export default function Navbar({ 
  activeMode, 
  setActiveMode, 
  selectedStadium, 
  setSelectedStadium, 
  stadiums, 
  currentLanguage, 
  setCurrentLanguage,
  accessibleMode,
  setAccessibleMode,
  onOpenPitchModal
}) {
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [tempApiKey, setTempApiKey] = useState(getStoredApiKey());
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveKey = () => {
    setStoredApiKey(tempApiKey);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      setShowKeyModal(false);
    }, 1200);
  };

  return (
    <>
      <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Brand / Logo */}
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveMode('fan')}>
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-blue-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <Trophy className="w-6 h-6 text-slate-950 stroke-[2.5]" />
                </div>
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-slate-950"></span>
                </span>
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent font-display">
                    ArenaPulse
                  </span>
                  <span className="text-xs font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    FIFA 2026
                  </span>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">Next-Gen Stadium Ops & Fan Experience OS</p>
              </div>
            </div>

            {/* Stadium Selector */}
            <div className="hidden md:flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 shadow-inner">
              {Object.values(stadiums).map(st => {
                const isSelected = selectedStadium.id === st.id;
                return (
                  <button
                    key={st.id}
                    onClick={() => setSelectedStadium(st)}
                    className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <span>{st.flag}</span>
                    <span className="truncate max-w-[120px]">{st.name.split('(')[0].trim()}</span>
                  </button>
                );
              })}
            </div>

            {/* Mode Navigation & Action Buttons */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* Fan Mode vs Ops Command Toggle */}
              <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center">
                <button
                  onClick={() => setActiveMode('fan')}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    activeMode === 'fan'
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Fan Hub</span>
                </button>
                <button
                  onClick={() => setActiveMode('ops')}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    activeMode === 'ops'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Ops Command</span>
                </button>
              </div>

              {/* Universal Accessibility Mode Toggle */}
              <button
                onClick={() => setAccessibleMode(!accessibleMode)}
                title={accessibleMode ? "Accessibility Mode Active" : "Enable Accessibility Mode"}
                className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition-all ${
                  accessibleMode 
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Accessibility className={`w-4 h-4 ${accessibleMode ? 'text-amber-400 animate-pulse' : ''}`} />
                <span className="hidden lg:inline">{accessibleMode ? 'ADA Mode ON' : 'ADA'}</span>
              </button>

              {/* Language Selector */}
              <div className="relative">
                <select
                  value={currentLanguage}
                  onChange={(e) => setCurrentLanguage(e.target.value)}
                  className="bg-slate-900 text-slate-200 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs font-medium focus:ring-2 focus:ring-emerald-500 outline-none cursor-pointer appearance-none pr-7"
                >
                  {SUPPORTED_LANGUAGES.map(lang => (
                    <option key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
                <Globe2 className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2.5 pointer-events-none" />
              </div>

              {/* Pitch & Hackathon Video Deck Button */}
              <button
                onClick={onOpenPitchModal}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold hover:brightness-110 shadow-md shadow-purple-900/30 transition-all"
              >
                <Tv2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Pitch & Demo</span>
              </button>

              {/* API Key Modal Button */}
              <button
                onClick={() => setShowKeyModal(true)}
                title="Configure Gemini API Key (Optional)"
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
              >
                <Key className="w-4 h-4 text-emerald-400" />
              </button>
            </div>
          </div>

          {/* Mobile Stadium Bar */}
          <div className="md:hidden flex items-center justify-between pb-3 pt-1 border-t border-slate-850">
            <span className="text-xs text-slate-400 font-medium">Active Host Venue:</span>
            <select
              value={selectedStadium.id}
              onChange={(e) => setSelectedStadium(stadiums[e.target.value])}
              className="bg-slate-900 text-slate-200 border border-slate-800 rounded-lg px-2 py-1 text-xs font-semibold"
            >
              {Object.values(stadiums).map(st => (
                <option key={st.id} value={st.id}>
                  {st.flag} {st.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </header>

      {/* API Key Configuration Modal */}
      {showKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2.5 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Gemini GenAI Configuration</h3>
                <p className="text-xs text-slate-400">Powered by Google Gemini 1.5 & Flash Models</p>
              </div>
            </div>

            <div className="bg-emerald-950/40 border border-emerald-800/40 rounded-xl p-3 mb-4 text-xs text-emerald-200/90 leading-relaxed">
              ✨ <strong>Autonomous Zero-Key Mode Active:</strong> You don't even need an API key to evaluate! ArenaPulse features an embedded stadium neural simulation engine with 100% full multi-agent conversational reasoning, SOP generation, and vision analysis.
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-300">
                Custom Google Gemini API Key (Optional)
              </label>
              <input
                type="password"
                placeholder="AIzaSy..."
                value={tempApiKey}
                onChange={(e) => setTempApiKey(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="text-[11px] text-slate-400">
                Keys are stored only locally in your browser's <code className="bg-slate-800 px-1 py-0.5 rounded text-slate-300">localStorage</code>.
              </p>
            </div>

            <div className="mt-6 flex items-center justify-end space-x-2">
              <button
                onClick={() => setShowKeyModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveKey}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20 transition-all"
              >
                {savedSuccess ? 'Saved Successfully! ✓' : 'Save & Connect'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
