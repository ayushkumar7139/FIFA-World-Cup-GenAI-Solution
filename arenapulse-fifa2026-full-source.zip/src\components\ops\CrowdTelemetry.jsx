import React, { useState, useEffect } from 'react';
import { 
  Users, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight, 
  Zap, 
  RefreshCw,
  Gauge
} from 'lucide-react';

export default function CrowdTelemetry({ stadium }) {
  const [zones, setZones] = useState(stadium.zones);
  const [totalEntered, setTotalEntered] = useState(58240);
  const [flowRate, setFlowRate] = useState(480); // fans per min

  // Dynamic sensor simulation
  useEffect(() => {
    setZones(stadium.zones);
  }, [stadium.id]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTotalEntered(prev => Math.min(stadium.capacity, prev + Math.floor(Math.random() * 25) + 10));
      setFlowRate(prev => Math.floor(450 + Math.random() * 60));
    }, 4000);
    return () => clearInterval(timer);
  }, [stadium.capacity]);

  const simulateSurge = (gateId) => {
    setZones(prev => prev.map(z => {
      if (z.id === gateId) {
        return { ...z, queueMin: z.queueMin + 12, density: 'Critical Surge', status: 'surging' };
      }
      return z;
    }));
  };

  const normalizeAll = () => {
    setZones(stadium.zones.map(z => ({
      ...z,
      queueMin: Math.max(2, Math.floor(z.queueMin / 2)),
      density: 'Low',
      status: 'smooth'
    })));
  };

  const capacityPercentage = Math.round((totalEntered / stadium.capacity) * 100);

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <Gauge className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white font-display">
              Real-Time Turnstile & Concourse Crowd Telemetry
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Automated sensor monitoring across 6 entry perimeters and concourse sectors
          </p>
        </div>

        {/* Quick Simulator Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => simulateSurge('z-c')}
            className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-bold transition-colors"
          >
            Simulate Surge at Gate C
          </button>
          <button
            onClick={normalizeAll}
            className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold transition-colors"
          >
            Reset to Optimal
          </button>
        </div>
      </div>

      {/* High-level KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase">
            <span>Stadium Inflow</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {totalEntered.toLocaleString()} <span className="text-xs text-slate-400 font-normal">/ {stadium.capacity.toLocaleString()}</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${capacityPercentage}%` }}
            ></div>
          </div>
          <div className="text-[11px] text-emerald-400 font-semibold mt-1.5">
            {capacityPercentage}% of capacity checked in
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase">
            <span>Turnstile Flow Rate</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            {flowRate} <span className="text-xs text-slate-400 font-normal">fans/min</span>
          </div>
          <div className="text-[11px] text-teal-300 flex items-center space-x-1 mt-3">
            <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
            <span>Throughput within safety thresholds</span>
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase">
            <span>Critical Surge Gates</span>
            <AlertTriangle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-extrabold text-rose-400 mt-1">
            {zones.filter(z => z.status === 'surging').length} <span className="text-xs text-slate-400 font-normal">Gates</span>
          </div>
          <div className="text-[11px] text-rose-300 mt-3">
            Gate C exceeding 15 min wait threshold
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase">
            <span>Security Screening Avg</span>
            <Zap className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-1">
            18.4 <span className="text-xs text-slate-400 font-normal">sec / fan</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-3">
            Clear bag compliance rate: 94.2%
          </div>
        </div>
      </div>

      {/* Detailed Perimeter Gate Matrix */}
      <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
        <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Perimeter Gate Queue Matrix</h3>
          <span className="text-[11px] text-emerald-400 font-semibold flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Live Telemetry 100ms Feed</span>
          </span>
        </div>

        <div className="divide-y divide-slate-850">
          {zones.map((zone) => {
            const isSurging = zone.status === 'surging';
            return (
              <div key={zone.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-900/50 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    isSurging ? 'bg-rose-500 animate-pulse' : zone.status === 'moderate' ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}></div>
                  <div>
                    <div className="text-xs font-bold text-white">{zone.name}</div>
                    <div className="text-[11px] text-slate-400">
                      Crowd Density: <span className={isSurging ? 'text-rose-400 font-semibold' : 'text-slate-300'}>{zone.density}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-white">{zone.queueMin} min queue</div>
                    <div className="text-[10px] text-slate-400">Turnstiles active: 14/14</div>
                  </div>
                  {isSurging && (
                    <button
                      onClick={() => alert(`Autonomous Dispatch Initiated: 8 mobile ticket scanners dispatched to ${zone.name}. Dynamic rerouting push alert triggered.`)}
                      className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
                    >
                      Trigger Surge SOP
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
