import React, { useState, useEffect } from 'react';
import { 
  HeartHandshake, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  ShieldCheck, 
  Eye, 
  Radio, 
  AlertCircle, 
  CheckCircle2, 
  MapPin, 
  Headphones, 
  Activity 
} from 'lucide-react';

export default function SensoryAndAccessibility({ stadium, currentLanguage }) {
  const [decibels, setDecibels] = useState(88);
  const [isPlayingAudioDesc, setIsPlayingAudioDesc] = useState(false);
  const [volunteerSummoned, setVolunteerSummoned] = useState(false);
  const [customCommentary, setCustomCommentary] = useState(
    "Match 84th minute: Ball played out wide right to the winger, advancing past the 30-yard mark. Stadium crowd roaring at 92 dB. Defender slides in to concede a corner on the south concourse end."
  );

  // Dynamic decibel simulator
  useEffect(() => {
    const interval = setInterval(() => {
      setDecibels(prev => {
        const delta = Math.floor(Math.random() * 9) - 4;
        return Math.min(108, Math.max(65, prev + delta));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleAudioDescription = () => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis not supported in this browser.');
      return;
    }

    if (isPlayingAudioDesc) {
      window.speechSynthesis.cancel();
      setIsPlayingAudioDesc(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(customCommentary);
      utterance.rate = 1.05;
      utterance.onend = () => setIsPlayingAudioDesc(false);
      utterance.onerror = () => setIsPlayingAudioDesc(false);
      window.speechSynthesis.speak(utterance);
      setIsPlayingAudioDesc(true);
    }
  };

  const handleSummonVolunteer = () => {
    setVolunteerSummoned(true);
    setTimeout(() => {
      alert(`Accessibility Volunteer dispatched! Volunteer #V-204 (Sarah) has accepted your beacon and will arrive at your section in approx 3 minutes.`);
    }, 600);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl shadow-xl p-5 backdrop-blur-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <HeartHandshake className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white font-display">
              FIFA Universal Accessibility & Sensory Suite
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Neurodivergent accommodations, live descriptive audio, and mobility support at {stadium.name}
          </p>
        </div>

        {/* Live Sound Level Badge */}
        <div className="flex items-center space-x-2 bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800">
          <Activity className={`w-4 h-4 ${decibels > 95 ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`} />
          <div>
            <div className="text-[10px] text-slate-400 font-bold uppercase">Pitch Noise Level</div>
            <div className="text-xs font-extrabold text-white">
              {decibels} dB <span className={`text-[10px] font-semibold ${decibels > 95 ? 'text-rose-400' : 'text-emerald-400'}`}>({decibels > 95 ? 'High Noise' : 'Normal'})</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Suite Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Sensory Calm Room Info */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-purple-400 mb-2">
              <Headphones className="w-4 h-4" />
              <h3 className="text-sm font-bold text-white">Sensory Calm Room</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Certified quiet space designed for neurodivergent guests, autistic fans, or those experiencing sensory overload.
            </p>
            <div className="mt-3 bg-purple-950/30 border border-purple-800/40 rounded-lg p-2.5 text-[11px] text-purple-200 space-y-1">
              <div><strong>Location:</strong> Section 118 & Section 232 Concourse</div>
              <div><strong>Amenities:</strong> Weighted lap pads, fidget kits, bubble tubes & dimmed lighting.</div>
            </div>
          </div>

          <button
            onClick={() => alert(`Directions loaded: Proceed to Section 118 Concourse. The Sensory Room is located right across from Guest Relations.`)}
            className="w-full py-2 bg-purple-600/30 hover:bg-purple-600/40 text-purple-200 border border-purple-500/40 rounded-lg text-xs font-bold transition-colors"
          >
            Locate Sensory Room on Map
          </button>
        </div>

        {/* Generative Live Audio Description */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-emerald-400 mb-2">
              <Eye className="w-4 h-4" />
              <h3 className="text-sm font-bold text-white">Descriptive Audio Commentary</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Real-time GenAI audio narration optimized with visual details (player positioning, kit colors, tactical shape) for blind & low-vision fans.
            </p>

            <div className="mt-2.5 p-2.5 bg-slate-900 rounded-lg border border-slate-800 text-[11px] text-slate-300 italic">
              "{customCommentary}"
            </div>
          </div>

          <button
            onClick={handleToggleAudioDescription}
            className={`w-full py-2 rounded-lg text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
              isPlayingAudioDesc
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
            }`}
          >
            {isPlayingAudioDesc ? (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span>Stop Live Audio Feed</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5" />
                <span>Play Live Descriptive Audio Feed</span>
              </>
            )}
          </button>
        </div>

        {/* Volunteer SOS Beacon */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 mb-2">
              <ShieldCheck className="w-4 h-4" />
              <h3 className="text-sm font-bold text-white">On-Demand Companion Staff</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Need assistance reaching your seat, navigating escalators, or carrying concessions? Summon a certified FIFA accessibility volunteer directly to your location.
            </p>

            {volunteerSummoned && (
              <div className="mt-2 bg-emerald-950/40 border border-emerald-500/40 p-2.5 rounded-lg text-[11px] text-emerald-300 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Beacon active! Volunteer Sarah is en route (ETA ~3m).</span>
              </div>
            )}
          </div>

          <button
            onClick={handleSummonVolunteer}
            className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-extrabold transition-all shadow-md shadow-amber-500/20"
          >
            {volunteerSummoned ? 'Volunteer Beacon Active ✓' : 'Summon Accessibility Volunteer'}
          </button>
        </div>
      </div>
    </div>
  );
}
