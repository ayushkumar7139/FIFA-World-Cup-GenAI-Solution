import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';

const require = createRequire(import.meta.url);
const { ZipArchive } = require('./node_modules/archiver');

const distDir = path.resolve('dist');
const outputFile = path.resolve('../arenapulse-netlify-deploy.zip');

console.log(`Packaging ${distDir} into POSIX-compliant ${outputFile}...`);

const output = fs.createWriteStream(outputFile);
const archive = new ZipArchive({
  zlib: { level: 9 },
  forceLocalTime: true
});

output.on('close', () => {
  console.log(`✅ Success! POSIX Archive created: ${archive.pointer()} total bytes`);
});

archive.on('error', (err) => {
  console.error('Archive error:', err);
  process.exit(1);
});

archive.pipe(output);

// Add files individually with POSIX forward slashes
function addDirectory(currentDir, relativePath = '') {
  const items = fs.readdirSync(currentDir);
  for (const item of items) {
    const fullPath = path.join(currentDir, item);
    const posixRelPath = (relativePath ? `${relativePath}/${item}` : item).replace(/\\/g, '/');
    const stat = fs.statSync(fullPath);

    if (stat.isDirectory()) {
      addDirectory(fullPath, posixRelPath);
    } else {
      archive.file(fullPath, { name: posixRelPath });
      console.log(`Added: ${posixRelPath}`);
    }
  }
}

addDirectory(distDir);
archive.finalize();
