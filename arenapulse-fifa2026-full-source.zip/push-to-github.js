import git from 'isomorphic-git';
import http from 'isomorphic-git/http/node/index.js';
import fs from 'fs';

const repoUrl = process.argv[2];
const token = process.argv[3];

if (!repoUrl || !token) {
  console.log('Usage: node push-to-github.js <PUBLIC_REPO_URL> <GITHUB_TOKEN>');
  console.log('Example: node push-to-github.js https://github.com/your-username/arenapulse-fifa2026 ghp_xxxx');
  process.exit(1);
}

const dir = process.cwd();

async function push() {
  console.log(`Pushing to ${repoUrl}...`);
  try {
    await git.push({
      fs,
      http,
      dir,
      remote: 'origin',
      ref: 'main',
      url: repoUrl,
      onAuth: () => ({ username: token }),
    });
    console.log('🎉 Successfully pushed ArenaPulse 2026 to GitHub!');
  } catch (err) {
    console.error('Push failed:', err.message);
  }
}

push();
