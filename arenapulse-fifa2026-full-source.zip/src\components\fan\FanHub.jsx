import React, { useState } from 'react';
import { 
  MessageSquareText, 
  Map, 
  Recycle, 
  HeartHandshake, 
  Train, 
  Calendar, 
  Users, 
  Sparkles,
  ArrowRight
} from 'lucide-react';

import VoiceConcierge from './VoiceConcierge';
import InteractiveMap from './InteractiveMap';
import EcoVisionScanner from './EcoVisionScanner';
import SensoryAndAccessibility from './SensoryAndAccessibility';
import SmartTransit from './SmartTransit';

export default function FanHub({ stadium, currentLanguage, accessibleMode }) {
  const [activeTab, setActiveTab] = useState('concierge');

  const tabs = [
    { id: 'concierge', name: 'MatchVoice Concierge', icon: MessageSquareText, badge: 'AI Voice' },
    { id: 'map', name: '2.5D Stadium Wayfinder', icon: Map, badge: 'Interactive' },
    { id: 'eco', name: 'EcoVision Waste AI', icon: Recycle, badge: 'Sustainability' },
    { id: 'accessibility', name: 'Sensory & ADA Suite', icon: HeartHandshake, badge: 'Inclusion' },
    { id: 'transit', name: 'Smart Transit Hub', icon: Train, badge: 'Mobility' },
  ];

  return (
    <div className="space-y-6">
      {/* Stadium Banner & Matchday Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border border-emerald-500/30 p-6 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="text-2xl">{stadium.flag}</span>
              <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Official FIFA Host Venue
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
              {stadium.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              {stadium.city} • <span className="text-emerald-400 font-semibold">{stadium.role}</span>
            </p>
          </div>

          {/* Matchday Details Card */}
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex flex-wrap items-center gap-4 text-xs backdrop-blur-sm">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-[10px] text-slate-400 font-bold uppercase">Fixture</div>
                <div className="font-bold text-white">{stadium.upcomingMatch.fixture}</div>
              </div>
            </div>
            <div className="h-8 w-px bg-slate-800 hidden sm:block"></div>
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-blue-400" />
              <div>
                <div className="text-[10px] text-slate-400 font-bold uppercase">Attendance</div>
                <div className="font-bold text-emerald-300">{stadium.capacity.toLocaleString()} Capacity</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation Ribbon */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center space-x-2 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 scale-[1.02]'
                    : 'bg-slate-900/60 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.name}</span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${
                  isActive ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}>
                  {tab.badge}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Tab Content Area */}
      <div className="transition-all duration-200">
        {activeTab === 'concierge' && (
          <VoiceConcierge
            stadium={stadium}
            currentLanguage={currentLanguage}
            accessibleMode={accessibleMode}
          />
        )}

        {activeTab === 'map' && (
          <InteractiveMap
            stadium={stadium}
            accessibleMode={accessibleMode}
          />
        )}

        {activeTab === 'eco' && (
          <EcoVisionScanner
            stadium={stadium}
          />
        )}

        {activeTab === 'accessibility' && (
          <SensoryAndAccessibility
            stadium={stadium}
            currentLanguage={currentLanguage}
          />
        )}

        {activeTab === 'transit' && (
          <SmartTransit
            stadium={stadium}
          />
        )}
      </div>
    </div>
  );
}
